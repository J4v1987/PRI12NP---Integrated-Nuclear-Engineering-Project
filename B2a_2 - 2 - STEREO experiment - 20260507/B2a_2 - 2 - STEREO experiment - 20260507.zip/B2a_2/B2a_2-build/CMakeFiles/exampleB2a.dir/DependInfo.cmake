
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/homes/s25hussa/geant4/B2a_2/exampleB2a.cc" "CMakeFiles/exampleB2a.dir/exampleB2a.cc.o" "gcc" "CMakeFiles/exampleB2a.dir/exampleB2a.cc.o.d"
  "/homes/s25hussa/geant4/B2a_2/src/B2ActionInitialization.cc" "CMakeFiles/exampleB2a.dir/src/B2ActionInitialization.cc.o" "gcc" "CMakeFiles/exampleB2a.dir/src/B2ActionInitialization.cc.o.d"
  "/homes/s25hussa/geant4/B2a_2/src/B2EventAction.cc" "CMakeFiles/exampleB2a.dir/src/B2EventAction.cc.o" "gcc" "CMakeFiles/exampleB2a.dir/src/B2EventAction.cc.o.d"
  "/homes/s25hussa/geant4/B2a_2/src/B2PrimaryGeneratorAction.cc" "CMakeFiles/exampleB2a.dir/src/B2PrimaryGeneratorAction.cc.o" "gcc" "CMakeFiles/exampleB2a.dir/src/B2PrimaryGeneratorAction.cc.o.d"
  "/homes/s25hussa/geant4/B2a_2/src/B2RunAction.cc" "CMakeFiles/exampleB2a.dir/src/B2RunAction.cc.o" "gcc" "CMakeFiles/exampleB2a.dir/src/B2RunAction.cc.o.d"
  "/homes/s25hussa/geant4/B2a_2/src/B2TrackerHit.cc" "CMakeFiles/exampleB2a.dir/src/B2TrackerHit.cc.o" "gcc" "CMakeFiles/exampleB2a.dir/src/B2TrackerHit.cc.o.d"
  "/homes/s25hussa/geant4/B2a_2/src/B2TrackerSD.cc" "CMakeFiles/exampleB2a.dir/src/B2TrackerSD.cc.o" "gcc" "CMakeFiles/exampleB2a.dir/src/B2TrackerSD.cc.o.d"
  "/homes/s25hussa/geant4/B2a_2/src/B2aDetectorConstruction.cc" "CMakeFiles/exampleB2a.dir/src/B2aDetectorConstruction.cc.o" "gcc" "CMakeFiles/exampleB2a.dir/src/B2aDetectorConstruction.cc.o.d"
  "/homes/s25hussa/geant4/B2a_2/src/B2aDetectorMessenger.cc" "CMakeFiles/exampleB2a.dir/src/B2aDetectorMessenger.cc.o" "gcc" "CMakeFiles/exampleB2a.dir/src/B2aDetectorMessenger.cc.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
